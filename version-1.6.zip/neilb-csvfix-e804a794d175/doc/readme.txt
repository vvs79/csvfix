This is the CSVfix manual in HelpNDoc binary source format. To work on this, 
and to build the end-user documentation, you will need the Windows HelpNDoc tool, 
which is available free for non-commercial use at http://www.helpndoc.com. 

The pre-built end-user documentation for CSVfix for the current release is
always available at the CSVfix site at http://code.google.com/p/csvfix.

