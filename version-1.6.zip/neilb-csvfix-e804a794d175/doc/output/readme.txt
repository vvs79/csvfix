output directory for chm generation
