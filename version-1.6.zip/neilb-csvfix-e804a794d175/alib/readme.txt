This is the utility library supporting the CSVfix program. Note that not
all functionality is used by CSVfix, and it could usefully be pruned.
