#!bash

MYTH_TESTS=1
export MYTH_TESTS
bin/Debug/test.exe
