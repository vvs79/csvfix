//------------------------------------------------------------------------
// test_main.cpp
//
// main for library test
//
// Copyright (C) 2009 Neil Butterworth
//----------------------------------------------------------------------------

#include "a_myth.h"

#ifdef ALIB_TEST

int main( int argc, char *argv[] ) {

	return ALib::TestMain( argc, argv );

}

#endif

