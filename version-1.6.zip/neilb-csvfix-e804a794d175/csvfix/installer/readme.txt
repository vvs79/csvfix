This is the Inno Setup script that creates the Windows binary installation.
To run it, you need Inno Setup - get it at http://www.jrsoftware.org/isinfo.php
