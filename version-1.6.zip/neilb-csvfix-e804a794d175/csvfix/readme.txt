This is the C++ source for the CSVFix csv stream editor. You can build it 
either via the Makefile, or by using the Code::Blocks IDE, available 
from http://www.codeblocks.org - the file csvfix.cbp is the Code::Blocks
project file.
