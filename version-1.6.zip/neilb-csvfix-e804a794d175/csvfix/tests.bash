# tests.bash
# run all tests from codeblocks
cd test
runall
