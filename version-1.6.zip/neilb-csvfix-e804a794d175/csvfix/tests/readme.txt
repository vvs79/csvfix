Tests for CSVfix. These require the bash shell to run. 
To run all the tests, use:

	runtests

To run a single test, use:

	run1 testname

for example:

	run1 pad.test

The tests do not cover anywhere near all features of the CSVfix
command set, but they do (I think) give at least one test per command.
