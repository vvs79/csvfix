These are the correct outputs for the CSVfix tests, against which
each test run is diff'd. A test fails if it doesn't produce the
correct output as defined here.
