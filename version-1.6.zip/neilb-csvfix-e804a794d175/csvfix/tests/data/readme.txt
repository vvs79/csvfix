These are the input data for the CSVfix test suite
