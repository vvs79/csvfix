This is the source for a sample  DLL which implements a function that can be called
via the CSVFix "call" command - copy and modify this code to implement your own
function9s). This is Windows only stuff, at present.

Neil Butterworth
August 2012


