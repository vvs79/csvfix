readme.txt
----------

This is the source for CSVfix and the supporting alib library.
Building requires a GCC installation.  To build, enter the command 
"make win" for a Windows build, "make lin" for a Linux/Unix build, 
or "make mac" for a Mac build.

For further information, please see the CSVfix website 
at http://neilb.bitbucket.org/csvfix/

Neil Butterworth
13-Apr-2014




